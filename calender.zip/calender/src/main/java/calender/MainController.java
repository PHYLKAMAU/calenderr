import calender.CalendarService;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.List;

public class MainController {

    @FXML
    private Label eventLabel;

    @FXML
    private VBox eventVBox;

    @FXML
    private Button getEventsButton;

    @FXML
    public void initialize() {

    }

    @FXML
    public void handleAPICallButton() {
        try {
            List<Event> events = CalendarService.getEvents();

            if (!events.isEmpty()) {
                Event event = events.get(0);
                eventLabel.setText("Event: " + event.getTarget() + "\nID: " + event.getClass() + "\nURL: " + event.getSource());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

