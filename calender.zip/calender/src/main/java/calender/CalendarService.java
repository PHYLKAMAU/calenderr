package calender;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.event.Event;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CalendarService {

    private static final String API_URL = "https://api.apilayer.com/checkiday/events?timezone=America/Chicago&date=12/04/2023&adult=false";

    public static List<Event> getEvents() throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("apikey", "n4UQh4KpkVrzUCjdP38HM7ryxHRWnTYe")
                .build();

        Response response = client.newCall(request).execute();
        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode eventsNode = objectMapper.readTree(response.body().string()).get("events");

        List<Event> events = new ArrayList<>();
        Iterator<JsonNode> eventNodes = eventsNode.elements();

        while (eventNodes.hasNext()) {
            JsonNode eventNode = eventNodes.next();
            Event event = objectMapper.treeToValue(eventNode, Event.class);
            events.add(event);
        }

        return events;
    }
}

