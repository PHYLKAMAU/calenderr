module com.example.calender {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.fasterxml.jackson.databind;
    requires okhttp3;


    opens com.example.calender to javafx.fxml;
    exports com.example.calender;
}